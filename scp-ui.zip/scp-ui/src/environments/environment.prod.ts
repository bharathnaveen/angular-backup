export const environment = {
  production: true,
   baseUrl: 'http://10.2.1.230:7000'
};
