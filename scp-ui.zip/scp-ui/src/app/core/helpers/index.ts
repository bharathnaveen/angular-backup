import { environment } from '@scp-environments/environment';

export const loginURI = `${environment.baseUrl}/login`;
export const authURI = `${environment.baseUrl}/auth/isauthenticated`;
export const getuserURI = `${environment.baseUrl}/getuser`;
export const registerURI = `${environment.baseUrl}/users`;
