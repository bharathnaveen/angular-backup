import { NgModule, ModuleWithProviders, Optional, SkipSelf } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { AuthService, NotificationService, InterceptorService, PageaccessService } from './services';
import { NotificationComponent } from './components';
import { AuthGuard } from '@scp-core/services/auth.guard';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [NotificationComponent],
  exports: [NotificationComponent]
})
export class CoreModule {
  constructor (@Optional() @SkipSelf() parentModule: CoreModule) {
    if (parentModule) {
      throw new Error(
        'CoreModule is already loaded. Import it in the AppModule only');
    }
  }

  static forRoot(): ModuleWithProviders {
    return {
      ngModule: CoreModule,
      providers: [
        AuthService, NotificationService, AuthGuard, PageaccessService,
        { provide: HTTP_INTERCEPTORS, useClass: InterceptorService, multi: true },
      ]
    };
  }
}
