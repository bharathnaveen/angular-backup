export class User {
    name: string;
    email: string;
    mobile: number;
    role: string;
}

export const DefaultUserObj: User = {
    name: '',
    email: '',
    mobile: 0,
    role: ''
};

export class AddUserApiRes {
    message: string;
    success: boolean;
}

export class Notification {
    contextType: string;
    isActive: boolean;
    message: string;
}

export const NotificationState: Notification = {
    contextType: '',
    isActive: false,
    message: ''
};

export class Credentials {
    userName: string;
    pass: string;
}

export class LoginSuccess {
    token: string;
    success: boolean;
    message: string;
    users: LoggedInUser;
}

export class LoggedInUser {
    _id?: string;
    name: string;
    email: string;
    role: string;
    client?: string;
}

export class Authenicate {
    token: string;
    success: boolean;
}

export class PageAccess {
    canAddClient: boolean;
    canAddUser: boolean;
    canAddProject: boolean;
}
