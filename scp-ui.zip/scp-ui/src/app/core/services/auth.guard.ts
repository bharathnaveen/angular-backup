import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AuthService } from '@scp-core/services';
import { environment } from '@scp-environments/environment';

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private AS: AuthService, private router: Router) { }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      // if (this.AS.IsAuthenticate()) {
      //   console.log('AM IN');
      //   return true;
      // } else {
      //   console.log('AM Out');
      //   return false;
      // }
      return true;
  }

  checkIfLoggedIn() {
    if (this.AS.isLoggedIn) { return true; }

    // Navigate to the login page with extras
    this.router.navigate(['/auth']);
    return false;
  }
}
