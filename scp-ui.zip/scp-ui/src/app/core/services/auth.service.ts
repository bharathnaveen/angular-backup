import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { User, DefaultUserObj, AddUserApiRes, Credentials, LoginSuccess, Authenicate, LoggedInUser } from '@scp-core/models';
import { loginURI, authURI, getuserURI, registerURI } from '@scp-core/helpers';
import { NotificationService } from './notification.service';
import { PageaccessService } from './pageaccess.service';

@Injectable()
export class AuthService {

  private user = new BehaviorSubject<LoggedInUser>({} as LoggedInUser);
  user$ = this.user.asObservable();

  private isLoggedInSubject = new BehaviorSubject<boolean>(false);
  isLoggedIn$ = this.isLoggedInSubject.asObservable();

  private isLoginSubject = new BehaviorSubject<LoginSuccess>({} as LoginSuccess);
  isLogin$ = this.isLoginSubject.asObservable();

  // private isAuthenticateSubject = new BehaviorSubject<Authenicate>({} as Authenicate);
  // isAuthenticate$ = this.isAuthenticateSubject.asObservable();

  isLoggedIn: boolean;

  constructor(private http: HttpClient, private NS: NotificationService,
    private PAS: PageaccessService, private router: Router) {
    this.isLoggedIn$.subscribe(sub => this.isLoggedIn = sub);
    this.getUser();
  }

  // IsAuthenticate() {
  //   const token = localStorage.getItem('scp_key');
  //   this.http.post<Authenicate>(authURI, token).subscribe(res => {
  //     // return res.token !== null;
  //     // this.isAuthenticateSubject.next(res);
  //   });
  // }

  login(credentials: Credentials) {
    this.http.post<LoginSuccess>(loginURI, credentials).subscribe(res => {
      if (res.success) {
        localStorage.setItem('scp_key', res.token);
        this.isLoggedInSubject.next(true);
        this.isLoginSubject.next(res);
        this.PAS.mapUserRole(res.users.role);
        this.NS.trigger('success', `${res.message}`, 5000);
        if (res.users.role === 'PA') {
          this.router.navigate(['/client/clientlist']);
        } else {
          this.router.navigate(['/ticket/ticketlist']);
        }
      } else {
        this.NS.trigger('error', `${res.message}`, 5000);
      }
    });
  }

  getUser() {
    const getToken = localStorage.getItem('scp_key');
    if (getToken) {
      this.http.post<LoginSuccess>(getuserURI, { getToken }).subscribe(res => {
        this.isLoginSubject.next(res);
        this.PAS.mapUserRole(res.users.role);
      });
    }
  }

  addUser(user: User) {
    this.http.post<AddUserApiRes>(registerURI, user).subscribe(res => {
      if (res.success) {
        this.NS.trigger('success', 'Account Registered, Please check your mail', 5000);
        this.router.navigate(['/auth']);
      }
    });
  }
}
