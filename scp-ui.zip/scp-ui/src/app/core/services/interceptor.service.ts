import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';

@Injectable()
export class InterceptorService {

  constructor(private router: Router) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const token = localStorage.getItem('scp_key');
    req = req.clone({ setHeaders: { Authorization: `Bearer ${token}` } });
    return next
      .handle(req)
      .do((event: HttpEvent<any>) => {
        // Do things if success other than 401
      }, (err: any) => {
        if (err instanceof HttpErrorResponse) {
          if (err.status === 401) {
            // Redirect to Login
            this.router.navigate(['/auth']);
          }
        }
    });
  }

}
