import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Notification, NotificationState } from '@scp-core/models';

@Injectable()
export class NotificationService {

  private subject = new BehaviorSubject<Notification>(NotificationState);
  notification$ = this.subject.asObservable();

  constructor() { }

  trigger(contextType = 'neutral', message: string, timeout = 5000) {
    this.subject.next({ contextType, isActive: true, message });
    setTimeout(() => {
      this.subject.next({ contextType: '', isActive: false, message: '' });
    }, timeout);
  }

}
