import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { PageAccess } from '@scp-core/models';


@Injectable()
export class PageaccessService {

  defaultPageAccess: PageAccess = {
    canAddClient: false,
    canAddUser: false,
    canAddProject: false,
  };
  private pageAccessSubject = new BehaviorSubject<PageAccess>(this.defaultPageAccess);
  pageAccess$ = this.pageAccessSubject.asObservable();
  PA_access = {
    canAddClient: true,
    canAddUser: true,
    canAddProject: true,
  };
  CA_access = {
    canAddClient: false,
    canAddUser: true,
    canAddProject: true,
  };
  constructor() { }

  mapUserRole(roleType: string) {
    switch (roleType) {
      case 'PA': {
        this.pageAccessSubject.next({...this.PA_access});
        return;
      }
      case 'Client Admin': {
        this.pageAccessSubject.next({...this.CA_access});
        return;
      }
      default: {
        this.pageAccessSubject.next({...this.defaultPageAccess});
        return;
      }
    }
  }
}
