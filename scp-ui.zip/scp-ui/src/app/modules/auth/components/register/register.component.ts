import { Component, OnInit } from '@angular/core';
import { AuthService } from '@scp-core/services';
import { User } from '@scp-core/models';

@Component({
  selector: 'scp-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user = {} as User;
  emailValid= true;
  constructor(private auth: AuthService) { }

  ngOnInit() {
  }

  addUser() {
    this.auth.addUser(this.user);
  }

  checkEmail(email){
    let pattern=/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
    this.emailValid = email.match(pattern) == null ? false : true;
  }
}
