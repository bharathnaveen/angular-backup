import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { AuthService } from '@scp-core/services';
import { Router } from '@angular/router';

import { NotificationService } from '@scp-core/services';

@Component({
  selector: 'scp-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginComponent implements OnInit {

  userName: string;
  pass: string;

  constructor(private auth: AuthService, private router: Router) { }

  ngOnInit() {
    this.auth.isLogin$.subscribe(res => {
      if (res.users && res.users.name) {
        if (res.users.role === 'PA') {
          this.router.navigate(['/client/clientlist']);
        } else {
          this.router.navigate(['/ticket/ticketlist']);
        }
      }
    });
  }

  login() {
    this.auth.login({ userName: this.userName, pass: this.pass });
  }

}
history.pushState(null, null, document.URL);
window.addEventListener('popstate', function () {
    history.pushState(null, null, document.URL);
});
