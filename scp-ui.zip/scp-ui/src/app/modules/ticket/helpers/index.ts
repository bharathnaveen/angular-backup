import { environment } from '@scp-environments/environment';

export const addTicketURI = `${environment.baseUrl}/tickets`;
export const getTicketURI = `${environment.baseUrl}/tickets/ticketlist`;
export const updateTicketURI = `${environment.baseUrl}/tickets/update`;