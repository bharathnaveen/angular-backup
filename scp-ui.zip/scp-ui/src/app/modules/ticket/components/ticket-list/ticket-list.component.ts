import { Component, OnInit } from '@angular/core';

import { TicketService } from '@scp-ticket/services';
import { Ticket } from '@scp-ticket/models';
import { Router } from '@angular/router';
import { LoginSuccess } from '@scp-core/models';
import { AuthService } from '@scp-core/services';

@Component({
  selector: 'scp-ticket-list',
  templateUrl: './ticket-list.component.html',
  styleUrls: ['./ticket-list.component.css']
})
export class TicketListComponent implements OnInit {
  tickets = [] as Ticket[];
  constructor(private TS: TicketService, private router: Router) { }

  ngOnInit() {
    this.getTickets();
    this.TS.getTickets();
  }

  getTickets() {
    this.TS.ticket$.subscribe(data => {
      this.tickets = data.tickets;
    });
  }

  editTicket(id) {
    this.router.navigate(['/ticket/ticketview',id]);
  }

}
