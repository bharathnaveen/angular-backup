import { Component, OnInit, ViewChild } from '@angular/core';

import { Client } from '@scp-client/models';
import { Project } from '@scp-project/models';
import { TicketService } from '@scp-ticket/services';

import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, map, merge } from 'rxjs/operators';
import { Ticket } from '@scp-ticket/models';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '@scp-core/services';
import { LoginSuccess } from '@scp-core/models';


@Component({
  selector: 'scp-ticket-form',
  templateUrl: './ticket-form.component.html',
  styleUrls: ['./ticket-form.component.css']
})
export class TicketFormComponent implements OnInit {

  clients: Client[] = [];
  projects: Project[] = [];
  ticket = {} as Ticket;
  ticketId: string;
  user = {} as LoginSuccess;

  formatter = (x: { name: string }) => x.name;

  @ViewChild('instance') instance: NgbTypeahead;
  focus$ = new Subject<string>();
  click$ = new Subject<string>();

  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      merge(this.focus$),
      merge(this.click$.pipe(filter(() => !this.instance.isPopupOpen()))),
      map(term => (term === '' ? []
        : this.clients.filter(v => v.name.toLowerCase().indexOf(term.toLowerCase()) > -1)).slice(0, 10))
    );

  searchProject = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      merge(this.focus$),
      merge(this.click$.pipe(filter(() => !this.instance.isPopupOpen()))),
      map(term => (term === '' ? []
        : this.projects.filter(v => v.name.toLowerCase().indexOf(term.toLowerCase()) > -1)).slice(0, 10))
    );

  constructor(private TS: TicketService, private AS: AuthService ) { }


  ngOnInit() {
    this.TS.client$.subscribe(clients => this.clients = clients);
    this.TS.getClients();
    this.TS.project$.subscribe(projects => this.projects = projects);
    this.TS.getProjects();
    this.AS.isLogin$.subscribe(user => {
      this.user = user;
    });
  }
    

  addTicket() {
    const reqObj = {
      client: this.ticket.client,
      project: this.ticket.project,
      user: this.user.users._id,
      title: this.ticket.title,
      description: this.ticket.description,
      priority: this.ticket.priority,
      severity: this.ticket.severity,
      attachment: this.ticket.attachment,
      status: this.ticket.status,
      raisedBy: this.user.users.name,   
    };
    this.TS.addTicket(reqObj);
  }

}

