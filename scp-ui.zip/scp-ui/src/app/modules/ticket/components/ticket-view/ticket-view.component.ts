import { Component, OnInit, ViewChild } from '@angular/core';

import { TicketService } from '@scp-ticket/services';
import { Ticket } from '@scp-ticket/models';
import { User } from '@scp-user/models';

import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';
import { Subject, Observable } from 'rxjs';
import { debounceTime, distinctUntilChanged, merge, filter, map } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'scp-ticket-view',
  templateUrl: './ticket-view.component.html',
  styleUrls: ['./ticket-view.component.css']
})
export class TicketViewComponent implements OnInit {

  ticketId: string;
  ticket: Ticket[] = [];
  fieldName: string;
  fieldValue: string;
  users: User[] = [];

  formatter = (x: { name: string }) => x.name;

  @ViewChild('instance') instance: NgbTypeahead;
  focus$ = new Subject<string>();
  click$ = new Subject<string>();

  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      merge(this.focus$),
      merge(this.click$.pipe(filter(() => !this.instance.isPopupOpen()))),
      map(term => (term === '' ? []
        : this.users.filter(v => v.name.toLowerCase().indexOf(term.toLowerCase()) > -1)).slice(0, 10))
    );

 constructor(private TS: TicketService, private route: ActivatedRoute) { }

 fetchRouterParams() {
  this.route.params.subscribe(params => {
    if (params.id) { this.ticketId=params.id;}
  });
}

   ngOnInit() {
    this.fetchRouterParams();
    this.getTickets(this.ticketId);
    this.TS.getTickets();
    this.TS.user$.subscribe(users => this.users = users);
    this.TS.getUsers();
  }

  getTickets(id: string) {
    this.TS.ticket$.subscribe(tickets => {  
      if (tickets && tickets.tickets)  {
        this.ticket = tickets.tickets.filter(item => item['_id'] === id);  
      }
    });
  }

  updateTicket(fieldName, fieldValue, _id) {    
    this.TS.updateTicket( _id, fieldName, fieldValue );
  }

  getUsers() {
    this.TS.user$.subscribe(users => {
      this.users = users;
    });
  }
  
}
