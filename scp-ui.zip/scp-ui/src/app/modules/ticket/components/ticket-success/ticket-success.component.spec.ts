import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TicketSuccessComponent } from './ticket-success.component';

describe('TicketSuccessComponent', () => {
  let component: TicketSuccessComponent;
  let fixture: ComponentFixture<TicketSuccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TicketSuccessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TicketSuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
