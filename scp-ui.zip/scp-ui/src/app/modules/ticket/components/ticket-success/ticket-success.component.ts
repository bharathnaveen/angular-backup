import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'scp-ticket-success',
  templateUrl: './ticket-success.component.html',
  styleUrls: ['./ticket-success.component.css']
})
export class TicketSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
