import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';

import { getClientURI } from '@scp-client/helpers';
import { ClientsApiRes, Client } from '@scp-client/models';
import { Ticket, AddTicketApiRes, TicketsApiRes } from '@scp-ticket/models';
import { NotificationService, AuthService } from '@scp-core/services';
import { getProjectURI } from '@scp-project/helpers';
import { Project,  ProjectsApiRes } from '@scp-project/models';
import { addTicketURI, getTicketURI, updateTicketURI } from '@scp-ticket/helpers';
import { Router } from '@angular/router';
import { LoginSuccess } from '@scp-core/models';
import { getUserURI } from '@scp-user/helpers';
import { UsersApiRes, User } from '@scp-user/models';


@Injectable()
export class TicketService {

  private subject = new BehaviorSubject<TicketsApiRes>({} as TicketsApiRes);
  ticket$ = this.subject.asObservable();

  private clientSubject = new BehaviorSubject<Client[]>([]);
  client$ = this.clientSubject.asObservable();

  private projectSubject = new BehaviorSubject<Project[]>([]);
  project$ = this.projectSubject.asObservable();

  private userSubject = new BehaviorSubject<User[]>([]);
  user$ = this.userSubject.asObservable();

  user = {} as any;

  constructor(
    private http: HttpClient,
    private NS: NotificationService,
    private router: Router,
    private AS: AuthService
  ) { 
    this.userObjListener();
  }

  userObjListener() {
    this.AS.isLogin$.subscribe(user => {
      this.user = user.users;
    });
  }

  getClients() {
    this.http.get<ClientsApiRes>(getClientURI)
      .subscribe(data => this.clientSubject.next(data.clients));
  }

  getProjects() {
    this.http.get<ProjectsApiRes>(getProjectURI)
      .subscribe(data => this.projectSubject.next(data.projects));
  }

  addTicket(ticket: Ticket){
    this.http.post<AddTicketApiRes>(addTicketURI, ticket)
    .subscribe(res => {
      if (res.success) {
        this.router.navigate(['/ticket/ticketsuccess']);
      }
    });
  }

  getTickets(){
    this.http.post<TicketsApiRes>(getTicketURI, { userId: this.user._id })
    .subscribe(data => this.subject.next({tickets: data.tickets}));
  }

  updateTicket( _id, fieldName: string, fieldValue: string) {
    const reqObj = { 
     ticket: {_id }}
    switch (fieldName) {
      case "severity": {
        reqObj.ticket['severity'] = fieldValue;
        break;
      }
      case "priority": {
        reqObj.ticket['priority'] = fieldValue;
        break;
      }
      case "status": {
        reqObj.ticket['status'] = fieldValue;
        break;
      }    
    }
    this.http.post<AddTicketApiRes>(updateTicketURI, reqObj)
    .subscribe((res) => {
     if (res.success) {
        this.NS.trigger('success','Updated Successfully', 5000);
      }           
    });
  }  

  getUsers() {
    this.http.get<UsersApiRes>(getUserURI)
      .subscribe(data => this.userSubject.next(data.users));
  }
}
