import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TicketComponent, TicketFormComponent, TicketListComponent, TicketSuccessComponent, TicketViewComponent} from '@scp-ticket/components';
import { AuthGuard } from '@scp-core/services/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: TicketComponent,
    canActivate: [AuthGuard],
    children: [
      { path: '', component: TicketFormComponent },
      { path: 'ticketlist', component: TicketListComponent },
      { path: 'ticketsuccess', component: TicketSuccessComponent },
      { path: 'ticketview/:id', component: TicketViewComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TicketRoutingModule { }
