export class Ticket{
    client?: Object;
    project?: string;
    user?: string;
    title?: string;
    description?: string;
    priority?: string;
    severity?: string;
    _id?: string;
    status?: string;
    attachment?:string;
    raisedBy?: string;
    createdAt?: string;
      
}

export class AddTicketApiRes {
    message: string;
    success: boolean;
}

export class TicketsApiRes {
    tickets: Ticket[];
}