import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TicketRoutingModule } from './ticket-routing.module';
import { TicketComponent, TicketFormComponent, TicketListComponent, TicketSuccessComponent, TicketViewComponent } from './components';
import { SharedModule } from '@scp-shared/shared.module';
import { TicketService } from '@scp-ticket/services';

@NgModule({
  imports: [
    CommonModule,
    TicketRoutingModule,
    SharedModule
  ],
  declarations: [TicketComponent, TicketFormComponent, TicketListComponent, TicketSuccessComponent, TicketViewComponent],
  providers: [TicketService]
})
export class TicketModule { }
