import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ClientComponent, ClientFormComponent, ClientListComponent } from './components';
import { AuthGuard } from '@scp-core/services/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: ClientComponent,
    canActivate: [AuthGuard],
    children: [
       { path: '', component: ClientFormComponent },
       { path: 'clientlist', component: ClientListComponent },
       { path: 'clientupdateform/:id', component: ClientFormComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClientRoutingModule { }
