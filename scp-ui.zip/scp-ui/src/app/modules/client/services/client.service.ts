import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

import { addClientURI, getClientURI, deleteClientURI, updateClientURI } from '@scp-client/helpers';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Client, AddClientApiRes, ClientsApiRes, DeleteClientApiRes } from '@scp-client/models';


@Injectable()
export class ClientService {

  private subject = new BehaviorSubject<Client[]>([]);
  client$ = this.subject.asObservable();

  constructor(private http: HttpClient, private router: Router) { }

  getClients() {
    this.http.get<ClientsApiRes>(getClientURI)
      .subscribe(data => this.subject.next(data.clients));
  }

  addClient(client: Client) {
    const reqObj = {
      name: client.name,
      website: client.website,
      mailDomains: client.mailDomains
    };
    this.http.post<AddClientApiRes>(addClientURI, reqObj)
      .subscribe(res => {
        if (res.success) {
          this.router.navigate(['/client/clientlist']);
        }
      });
  }

  updateClient(updateObj: Client) {
    this.http.post<AddClientApiRes>(updateClientURI, updateObj).subscribe((res) => {
      if (res.success) {
        this.router.navigate(['/client/clientlist']);
      }
    });
  }

  deleteClient(id: string) {
    if (!(confirm('Are Sure? Do you want to delete?'))) {
      return;
    }
    this.http.post<DeleteClientApiRes>(deleteClientURI, { clientId: id })
      .subscribe(res => {
        const clients = this.subject.getValue().filter((client: Client) => id !== client._id);
        this.subject.next(clients);
      });
  }

}
