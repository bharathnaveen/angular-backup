import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { ClientService } from '@scp-client/services';
import { Client } from '@scp-client/models';

@Component({
  selector: 'scp-client-list',
  templateUrl: './client-list.component.html',
  styleUrls: ['./client-list.component.css']
})
export class ClientListComponent implements OnInit {
  clients: Client[] = [];
  constructor(private CS: ClientService, private router: Router) { }

  ngOnInit() {
    this.getClients();
    this.CS.getClients();
  }

  getClients() {
    this.CS.client$.subscribe(clients => this.clients = clients);
  }

  deleteClient(id) {
    this.CS.deleteClient(id);
  }

  editClient(id) {
    this.router.navigate(['/client/clientupdateform', id]);
  }
}
