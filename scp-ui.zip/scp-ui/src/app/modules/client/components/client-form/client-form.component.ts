import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ClientService } from '@scp-client/services';
import { Client } from '@scp-client/models';

@Component({
  selector: 'scp-client-form',
  templateUrl: './client-form.component.html',
  styleUrls: ['./client-form.component.css']
})
export class ClientFormComponent implements OnInit {

  client = { mailDomains: [] } as Client;
  onUpdateMode = false;
  clientId: string;
  mailExtension: string;

  constructor(private CS: ClientService, private route: ActivatedRoute) { }

  fetchRouterParams() {
    this.route.params.subscribe(params => {
      if (params.id) { this.getClientById(params.id); this.onUpdateMode = true; }
    });
  }

  ngOnInit() {
    this.fetchRouterParams();
  }

  addClient() {
    if (this.onUpdateMode) {
      this.CS.updateClient(this.client);
    } else {
      this.CS.addClient(this.client);
    }
  }

  getClientById(id: string) {
    this.clientId = id;
    this.CS.client$.subscribe(clients => {
      this.client = clients.filter(item => item['_id'] === id)[0];
    });
  }
  addDomain() {
    this.client.mailDomains.push(this.mailExtension);
    this.mailExtension = '';
  }

  deleteDomain(index) {
    this.client.mailDomains.splice(index, 1);
  }
}
