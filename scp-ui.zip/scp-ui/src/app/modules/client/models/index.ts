export class Client {
    name: string;
    website: string;
    mailDomains: string[];
    _id?: string;
}

export class AddClientApiRes {
    message: string;
    success: boolean;
}

export class ClientsApiRes {
    clients: Client[];
    message: string;
}

export class DeleteClientApiRes {
    message: string;
    success: boolean;
}
