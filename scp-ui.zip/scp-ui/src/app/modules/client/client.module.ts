import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClientRoutingModule } from './client-routing.module';
import { SharedModule } from '@scp-shared/shared.module';

import { ClientComponent, ClientFormComponent, ClientListComponent } from './components';
import { ClientService } from './services';

@NgModule({
  imports: [
    CommonModule,
    ClientRoutingModule,
    SharedModule,
  ],
  providers: [ClientService],
  declarations: [ClientComponent, ClientFormComponent, ClientListComponent]
})
export class ClientModule { }
