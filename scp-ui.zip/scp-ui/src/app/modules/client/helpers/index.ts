import { environment } from '@scp-environments/environment';

export const addClientURI = `${environment.baseUrl}/clients`;
export const getClientURI = `${environment.baseUrl}/clients/clientlist`;
export const deleteClientURI = `${environment.baseUrl}/clients/delete`;
export const updateClientURI = `${environment.baseUrl}/clients/update`;
