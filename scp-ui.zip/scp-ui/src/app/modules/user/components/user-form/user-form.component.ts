import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { UserService } from '@scp-user/services';
import { User } from '@scp-user/models';
import { Client } from '@scp-client/models';

import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, map, merge } from 'rxjs/operators';


@Component({
  selector: 'scp-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.css']
})
export class UserFormComponent implements OnInit {

  user = {} as User;
  emailValid = true;
  userId: string;
  onUpdateMode = false;
  clients: Client[] = [];
  public model: any;

  formatter = (x: { name: string }) => x.name;

  @ViewChild('instance') instance: NgbTypeahead;
  focus$ = new Subject<string>();
  click$ = new Subject<string>();

  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      merge(this.focus$),
      merge(this.click$.pipe(filter(() => !this.instance.isPopupOpen()))),
      map(term => (term === '' ? []
        : this.clients.filter(v => v.name.toLowerCase().indexOf(term.toLowerCase()) > -1)).slice(0, 10))
    );

  constructor(private US: UserService, private route: ActivatedRoute) { }

  fetchRouterParams() {
    this.route.params.subscribe(params => {
      if (params.id) { this.getUserById(params.id); this.onUpdateMode = true; }
    });
  }


  ngOnInit() {
    this.fetchRouterParams();
    this.US.client$.subscribe(clients => this.clients = clients);
    this.US.getClients();
  }

  addUser() {
    if (this.onUpdateMode) {
      this.user.client = this.user.client['_id'];
      this.US.updateUser(this.user);
    } else {
      const reqObj = {
        name: this.user.name,
        email: this.user.email,
        mobile: this.user.mobile
      };
      this.US.addUser(reqObj);
    }
  }

  checkEmail(email) {
    const pattern = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/;
    this.emailValid = email.match(pattern) == null ? false : true;
  }

  getUserById(id: string) {
    this.userId = id;
    this.US.user$.subscribe(users => {
      this.user = users.filter(item => item['_id'] === id)[0];
    });
  }

  changeClient(event) {
    this.clients = event.target.value;
    console.log('test', event);
  }

}
