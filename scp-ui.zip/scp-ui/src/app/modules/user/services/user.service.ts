import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

import { addUserURI, getUserURI, updateUserURI } from '@scp-user/helpers';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { User, AddUserApiRes, UsersApiRes } from '@scp-user/models';

import { getClientURI } from '@scp-client/helpers';
import { ClientsApiRes, Client } from '@scp-client/models';
import { NotificationService } from '@scp-core/services';


@Injectable()
export class UserService {

  private subject = new BehaviorSubject<User[]>([]);
  user$ = this.subject.asObservable();

  private clientSubject = new BehaviorSubject<Client[]>([]);
  client$ = this.clientSubject.asObservable();

  constructor(private http: HttpClient, private router: Router, private NS: NotificationService) { }

  getUsers() {
    this.http.get<UsersApiRes>(getUserURI)
      .subscribe(data => {
        const userDetails = data.users.filter(item => item.email !== 'product@sennovate.com');
        this.subject.next(userDetails);
      });
  }

  addUser(user: User) {
    this.http.post<AddUserApiRes>(addUserURI, user)
      .subscribe(res => {
        if (res.success) {
          this.router.navigate(['/user/userlist']);
        }
      });
  }

  updateUser(updateObj: User) {
    this.http.post<AddUserApiRes>(updateUserURI, updateObj).subscribe((res) => {
      if (res.success) {
        this.NS.trigger('success','Updated Successfully', 5000);
        this.router.navigate(['/user/userlist']);
        
      }
    });
  }

  getClients() {
    this.http.get<ClientsApiRes>(getClientURI)
      .subscribe(data => this.clientSubject.next(data.clients));
  }
}
