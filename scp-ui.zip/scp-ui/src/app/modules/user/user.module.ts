import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { SharedModule } from '@scp-shared/shared.module';

import { UserComponent, UserFormComponent, UserListComponent } from './components';
import { UserService } from './services';


@NgModule({
  imports: [
    CommonModule,
    UserRoutingModule,
    SharedModule
  ],
  providers: [UserService],
  declarations: [UserComponent, UserFormComponent, UserListComponent]
})
export class UserModule { }
