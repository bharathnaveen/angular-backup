import { environment } from '@scp-environments/environment';

export const addUserURI = `${environment.baseUrl}/users`;
export const getUserURI = `${environment.baseUrl}/users/userlist`;
export const updateUserURI = `${environment.baseUrl}/users/update`;
