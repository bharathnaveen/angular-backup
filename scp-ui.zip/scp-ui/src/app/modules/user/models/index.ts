export class User {
    name: string;
    email: string;
    mobile: string;
    client?: Client;
    role?: string;
    _id?: string;
    ticket?: Object;
}

export class AddUserApiRes {
    message: string;
    success: boolean;
}

export class UsersApiRes {
    users: User[];
    message: string;
}

export class Client {
    name: string;
}
