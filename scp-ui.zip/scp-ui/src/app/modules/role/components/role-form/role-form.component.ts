import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { RoleService } from '@scp-role/services';
import { Role, UserDetails } from '@scp-role/models';

@Component({
  selector: 'scp-role-form',
  templateUrl: './role-form.component.html',
  styleUrls: ['./role-form.component.css']
})
export class RoleFormComponent implements OnInit {

 users : UserDetails[] = [];
 roles = {} as Role;

  constructor( private RS: RoleService, private route: ActivatedRoute) {}

  ngOnInit() {
    
    this.RS.getUserList();
    this.getUserList();   
  }

  getUserList(){
    this.RS.users$.subscribe(users => this.users=users);
  }

  addRoles(){
    this.RS.addRoles(this.roles);
  }

}
