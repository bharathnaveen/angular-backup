import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { RoleService } from '@scp-role/services';
import { Role } from '@scp-role/models';
import { AuthService } from '@scp-core/services';
import { LoginSuccess } from '@scp-core/models';


@Component({
  selector: 'scp-role-list',
  templateUrl: './role-list.component.html',
  styleUrls: ['./role-list.component.css']
})
export class RoleListComponent implements OnInit {

  roles: Role[] = [];
  user = {} as LoginSuccess;

  constructor(private RS: RoleService, private AS: AuthService, private router: Router) { }

  ngOnInit() {
    this.RS.getRoles();
    this.getRoles();
    this.AS.isLogin$.subscribe(user => this.user = user);
  }

  getRoles() {
    this.RS.role$.subscribe(roles => {
      this.roles = roles;
    });

  }

  deleteRole(id) {

    const reqObj = {
      roleId: id,
      user: this.user.users._id,

    };
    this.RS.deleteRole(reqObj);

  }


}
