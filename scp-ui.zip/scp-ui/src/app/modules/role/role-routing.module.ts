import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RoleComponent, RoleFormComponent, RoleListComponent } from './components';
import { AuthGuard } from '@scp-core/services/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: RoleComponent,
    canActivate: [AuthGuard],
    children: [
       { path: '', component: RoleFormComponent },
       { path: 'rolelist', component: RoleListComponent },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RoleRoutingModule { }
