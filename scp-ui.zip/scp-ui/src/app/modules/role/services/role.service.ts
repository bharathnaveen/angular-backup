import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

import { addRoleURI, deleteRoleURI, getUserlistURI, getRolelistURI } from '@scp-role/helpers';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Role, AddRoleApiRes, User, UserDetails, RoleApiRes, DeleteRoleApiRes } from '@scp-role/models';


@Injectable()
export class RoleService {

  private subject = new BehaviorSubject<UserDetails[]>([]);
  users$ = this.subject.asObservable();

  private rolesSubject = new BehaviorSubject<Role[]>([]);
  role$ = this.rolesSubject.asObservable();

  constructor(private http: HttpClient, private router: Router) { }

  getUserList() {
    this.http.get<User>(getUserlistURI)
      .subscribe(data => this.subject.next(data.users));
  }

  getRoles(){
    this.http.get<RoleApiRes>(getRolelistURI).subscribe(res => {
    this.rolesSubject.next(res.roles);
    });
  }

addRoles(roles:Role){
  this.http.post<AddRoleApiRes>(addRoleURI,roles).subscribe(res => {
  if (res.success){
    this.router.navigate(['/role/rolelist']);
  }
  });
}

deleteRole(reqObj) {
  if (!(confirm('Are Sure? Do you to delete?'))) {
    return;
  }
 
  this.http.post<DeleteRoleApiRes>(deleteRoleURI, reqObj)
    .subscribe(res => {
      const roles = this.rolesSubject.getValue().filter((roles: Role) => reqObj.roleId !== roles._id);
      this.rolesSubject.next(roles);
      
    });
}

}
