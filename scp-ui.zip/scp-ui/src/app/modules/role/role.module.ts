import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RoleRoutingModule } from './role-routing.module';
import { RoleComponent, RoleFormComponent, RoleListComponent } from './components';
import { SharedModule } from '@scp-shared/shared.module';
import { RoleService } from './services';

@NgModule({
  imports: [
    CommonModule,
    RoleRoutingModule,
    SharedModule
  ],
  providers: [RoleService],
  declarations: [RoleComponent, RoleFormComponent, RoleListComponent]
})
export class RoleModule { }
