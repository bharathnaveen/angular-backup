import { environment } from '@scp-environments/environment';

export const addRoleURI = `${environment.baseUrl}/roles`;
export const getUserlistURI = `${environment.baseUrl}/roles/userlist`;
export const deleteRoleURI = `${environment.baseUrl}/roles/delete`;
export const getRolelistURI = `${environment.baseUrl}/roles/rolelist`;