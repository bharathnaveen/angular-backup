export class Role {
    email: string;
    role: string; 
    _id?: string;
}

export class AddRoleApiRes {
    success: boolean;
    message: string;
}

export class DeleteRoleApiRes {
    message: string;
    success: boolean;
}

export class RoleApiRes{
    roles: Role[];
    message:string;
}

export class User {
    users: UserDetails[];
}

export class UserDetails{
    email:string;
}

