export class Project {
    name: string;
    client?: Client;
    _id?: string;
}

export class AddProjectApiRes {
    message: string;
    success: boolean;
}

export class ProjectsApiRes {
    projects: Project[];
    message: string;
}

export class DeleteProjectApiRes {
    message: string;
    success: boolean;
}

export class Client {
   // _id?: string;
    name: string;
}
