import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { ProjectService } from '@scp-project/services';
import { Project } from '@scp-project/models';
import { AuthService } from '@scp-core/services';
import { LoginSuccess, LoggedInUser } from '@scp-core/models';
import { Client } from '@scp-client/models';

import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, map, merge } from 'rxjs/operators';
import { User } from '@scp-core/models';

@Component({
  selector: 'scp-project-form',
  templateUrl: './project-form.component.html',
  styleUrls: ['./project-form.component.css'],
})
export class ProjectFormComponent implements OnInit {

  project = {} as Project;
  clients: Client[] = [];
  onUpdateMode = false;
  projectId: string;
  public model: any;
  user = {} as LoginSuccess;

  formatter = (x: { name: string }) => x.name;

  @ViewChild('instance') instance: NgbTypeahead;
  focus$ = new Subject<string>();
  click$ = new Subject<string>();

  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      merge(this.focus$),
      merge(this.click$.pipe(filter(() => !this.instance.isPopupOpen()))),
      map(term => (term === '' ? []
        : this.clients.filter(v => v.name.toLowerCase().indexOf(term.toLowerCase()) > -1)).slice(0, 10))
    );

  constructor(
    private PS: ProjectService,
    private AS: AuthService,
    private route: ActivatedRoute
  ) { }

  fetchRouterParams() {
    this.route.params.subscribe(params => {
      if (params.id) { this.getProjectById(params.id); this.onUpdateMode = true; }
    });
  }

  ngOnInit() {
    this.PS.client$.subscribe(clients => this.clients = clients);
    this.fetchRouterParams();
    this.PS.getClients();
    this.AS.isLogin$.subscribe(user => {
      this.user = user;
      // if (this.user) {
      //   this.project.client = { _id: this.user.users.client ? this.user.users.client : '' };
      // }
    });
  }

  addProject() {
    if (this.onUpdateMode) {
      this.PS.updateProject(this.project);
    } else {
      if (this.user.users.role === 'Client Admin') {
        const clientReqObj = { name: this.project.name, client: this.user.users.client };
        this.PS.addProject(clientReqObj);
      } else {
        const reqObj = { name: this.project.name, client: this.project.client['_id'] };
        this.PS.addProject(reqObj);
      }
    }
    // if (this.onUpdateMode) { reqObj['_id'] = this.projectId; }
    // this.onUpdateMode ? this.PS.updateProject(reqObj) : this.PS.addProject(reqObj);
  }

  getProjectById(id: string) {
    this.projectId = id;
    this.PS.project$.subscribe(projects => {
      this.project = projects.filter(item => item['_id'] === id)[0];
    });
  }
}
