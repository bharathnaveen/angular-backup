import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'scp-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})
export class ProjectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
