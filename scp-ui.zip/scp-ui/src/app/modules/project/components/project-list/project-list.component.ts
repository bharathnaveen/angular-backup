import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { ProjectService } from '@scp-project/services';
import { Project } from '@scp-project/models';
import { AuthService } from '@scp-core/services';
import { LoginSuccess } from '@scp-core/models';

@Component({
  selector: 'scp-project-list',
  templateUrl: './project-list.component.html',
  styleUrls: ['./project-list.component.css']
})
export class ProjectListComponent implements OnInit {
  projects: Project[] = [];
  user = {} as LoginSuccess;
  constructor(private PS: ProjectService, private AS: AuthService, private router: Router) { }

  ngOnInit() {
    this.getProjects();
    this.PS.getProjects();
  }

  getProjects() {
    this.AS.isLogin$.subscribe(user => this.user = user);
    this.PS.project$.subscribe(projects => this.projects = projects);
  }

  deleteProject(id) {
    const reqObj = {
      projectId: id,
      client: this.user.users._id,
    };
    this.PS.deleteProject(reqObj);
  }

  editProject(id) {
    this.router.navigate(['/project/projectupdateform', id]);
  }

}
