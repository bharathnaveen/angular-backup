import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

import { addProjectURI, getProjectURI, deleteProjectURI, updateProjectURI } from '@scp-project/helpers';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Project, AddProjectApiRes, ProjectsApiRes, DeleteProjectApiRes } from '@scp-project/models';
import { getClientURI } from '@scp-client/helpers';
import { ClientsApiRes, Client } from '@scp-client/models';
import { NotificationService } from '@scp-core/services';

@Injectable()
export class ProjectService {

  private subject = new BehaviorSubject<Project[]>([]);
  project$ = this.subject.asObservable();

  private clientSubject = new BehaviorSubject<Client[]>([]);
  client$ = this.clientSubject.asObservable();

  constructor(private http: HttpClient, private router: Router, private NS: NotificationService) { }

  getProjects() {
    this.http.get<ProjectsApiRes>(getProjectURI)
      .subscribe(data => this.subject.next(data.projects));
  }

  addProject(project) {
    this.http.post<AddProjectApiRes>(addProjectURI, project)
      .subscribe(res => {
        if (res.success) {
          this.router.navigate(['/project/projectlist']);
        }
      });
  }

  updateProject(updateObj: Project) {
    this.http.post<AddProjectApiRes>(updateProjectURI, updateObj).subscribe((res) => {
      if (res.success) {
        this.NS.trigger('success', 'Updated Successfully', 5000);
        this.router.navigate(['/project/projectlist']);
      }
    });
  }

  deleteProject(reqObj) {
    if (!(confirm('Are Sure? Do you to delete?'))) {
      return;
    }
    this.http.post<DeleteProjectApiRes>(deleteProjectURI, reqObj)
      .subscribe(res => {
        const projects = this.subject.getValue().filter((project: Project) => reqObj.projectId !== project._id);
        this.subject.next(projects);
      });
  }

  getClients() {
    this.http.get<ClientsApiRes>(getClientURI)
      .subscribe(data => this.clientSubject.next(data.clients));
  }
}
