import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ProjectComponent, ProjectFormComponent, ProjectListComponent } from './components';
import { AuthGuard } from '@scp-core/services/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: ProjectComponent,
    canActivate: [AuthGuard],
    children: [
       { path: '', component: ProjectFormComponent },
       { path: 'projectlist', component: ProjectListComponent },
       { path: 'projectupdateform/:id', component: ProjectFormComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProjectRoutingModule { }
