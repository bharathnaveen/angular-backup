import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProjectRoutingModule } from './project-routing.module';
import { SharedModule } from '@scp-shared/shared.module';

import { ProjectComponent, ProjectFormComponent, ProjectListComponent } from './components';
import { ProjectService } from './services';

@NgModule({
  imports: [
    CommonModule,
    ProjectRoutingModule,
    SharedModule
  ],
  providers: [ProjectService],
  declarations: [ProjectComponent, ProjectFormComponent, ProjectListComponent]
})
export class ProjectModule { }
