import { environment } from '@scp-environments/environment';

export const addProjectURI = `${environment.baseUrl}/projects`;
export const getProjectURI = `${environment.baseUrl}/projects/projectlist`;
export const deleteProjectURI = `${environment.baseUrl}/projects/delete`;
export const updateProjectURI = `${environment.baseUrl}/projects/update`;
