import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { RouterModule } from '@angular/router';
import { NavbarComponent, InlineSpinnerComponent, FooterComponent} from './components';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    NgbModule.forRoot(),
    RouterModule,
    FormsModule
  ],
  declarations: [NavbarComponent, InlineSpinnerComponent, FooterComponent],
  exports: [CommonModule, NavbarComponent, InlineSpinnerComponent, FooterComponent, NgbModule, FormsModule]
})
export class SharedModule { }
