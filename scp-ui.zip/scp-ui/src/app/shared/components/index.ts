export { InlineSpinnerComponent } from './inline-spinner/inline-spinner.component';
export { NavbarComponent } from './navbar/navbar.component';
export { FooterComponent } from './footer/footer.component';

