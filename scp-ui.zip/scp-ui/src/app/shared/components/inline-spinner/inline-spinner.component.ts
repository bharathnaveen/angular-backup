import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'scp-inline-spinner',
  templateUrl: './inline-spinner.component.html',
  styleUrls: ['./inline-spinner.component.css']
})
export class InlineSpinnerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
