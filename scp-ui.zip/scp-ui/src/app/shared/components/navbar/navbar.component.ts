import { Component, OnInit } from '@angular/core';
import { RouterLinkActive } from '@angular/router';
import { AuthService, PageaccessService } from '@scp-core/services';
import { LoginSuccess, PageAccess } from '@scp-core/models';


@Component({
  selector: 'scp-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  user = {} as LoginSuccess;
  canAddClient = false;
  canAddUser = false;
  canAddProject = false;
  PA = {} as PageAccess;

  constructor(private AS: AuthService, private PAS: PageaccessService) { }

  token = localStorage.getItem('scp_key');

  ngOnInit() {
    this.AS.isLogin$.subscribe(user => this.user = user);
    this.pageAccessSubscriber();
  }

  logout() {
    localStorage.removeItem('scp_key');
  }

  pageAccessSubscriber() {
    this.PAS.pageAccess$.subscribe(role => {
      this.PA = role;
    });
  }
}
