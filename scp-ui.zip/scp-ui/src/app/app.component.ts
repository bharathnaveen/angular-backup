import { Component } from '@angular/core';
import { AuthService } from '@scp-core/services';
import { NotificationService } from '@scp-core/services';
import { Notification, NotificationState } from './core/models';

@Component({
  selector: 'scp-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  notification: Notification = NotificationState;

  constructor(private auth: AuthService, private notificationService: NotificationService) {
    this.notificationService.notification$
      .subscribe(notification => this.notification = notification);
  }
}
